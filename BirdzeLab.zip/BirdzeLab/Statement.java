class Statement 
{
	public static void main(String[] args) 
	{
		int var1=5;
		int var2=6;
		if((var2=1)==var1)
		System.out.println(var2);
		else
			System.out.println(++var2);
	}
}
