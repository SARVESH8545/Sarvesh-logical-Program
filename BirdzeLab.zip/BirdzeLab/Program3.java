 public class Program3 
{
	public String getProgram3(){
	//public static void main(String[] args) 
	
		return "Program";
	}
}
