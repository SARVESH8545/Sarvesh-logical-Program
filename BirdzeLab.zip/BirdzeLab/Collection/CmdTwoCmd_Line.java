class CmdTwoCmd_Line 
{
	public static void main(String[] args) 
	{
		int f=Integer.parseInt(args[0]);
        int s=Integer.parseInt(args[1]);
		System.out.println(f+s);
	}
}
