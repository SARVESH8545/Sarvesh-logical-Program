package Collection;

import java.util.TreeSet;

public class LinkedHashSet_DEmo {



	public static void main(String[] args) {
	//LinkedHashSet lhs=new LinkedHashSet();
	//HashSet lhs=new HashSet();
		TreeSet lhs=new TreeSet();
	lhs.add(100);
	lhs.add(1);
	lhs.add(5);
	lhs.add(3);
	lhs.add(55);
	lhs.add(20);
	lhs.add(100);
	lhs.add(1);
	lhs.add(5);
	lhs.add(55);
	lhs.add(500);
	System.out.println(lhs);
	
	}

}
