package Collection;

import java.util.*;


public class TreeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet t=new TreeSet();
 ((List) t).add(5);
((List) t).add(2);
((List) t).add(3);
ArrayList al=new ArrayList();
Collections.reverse(al);
	System.out.print(al); 
	}

}
