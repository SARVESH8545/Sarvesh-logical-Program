package array1;
//Program to print the elements of 
//an array present on even position

public class Array_element_even_postion {
	public static void main(String[] args) {
		
	
int a[]=new int[] {1,2,3,4,5,6,7,8};

System.out.println("present even postion");
for(int i=0;i<a.length;i=i+2)
{
	System.out.print(a[i]+" ");
	}

}
}
