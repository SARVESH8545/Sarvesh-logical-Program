package array1;

import java.util.Arrays;

public class Array_sorting {

	public static void main(String[] args) {
		int a[]=new int[] {1,8,4,64,78,45};
		//Arrays.sort(a);
		//String s=Arrays.toString(a);
		//System.out.println(s);
      int temp=0;
      System.out.println("Element of orignal array");
      for (int i = 0; i < a.length; i++) {
		System.out.print(a[i]+" ");
		//sort the array in accending order
		for(int j=i+1;j<a.length;j++)
		{
			if(a[i]<a[j]) {
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
		
	}
      System.out.println();
      System.out.println("Accending order:");
      for (int i = 0; i < a.length; i++) {
		System.out.print(a[i]+" ");
		
	}
	}

}
