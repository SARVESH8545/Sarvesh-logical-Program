package array1;

public class ArrayElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int a[]=new int[] {1,2,3,4,5};
   System.out.println("Print the array element");
   for(int i=0;i<a.length;i++)
   {
	   System.out.print(a[i]+" ");
   }
	}

}
