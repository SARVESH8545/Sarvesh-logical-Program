package NumberPattern;

public class Snumberpattern12 {

	public static void main(String[] args) {
		

	}

}
