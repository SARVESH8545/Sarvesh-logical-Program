package string1;

public class  Main {

	public static void main(String[] args) {
		int i=10;
		while(i++<=10)
		{
			i++;
		}
		System.out.println(i);
	}}
