package string1;

public class Warmwaup {

	public static void main(String[] args) {
		


	}

}
