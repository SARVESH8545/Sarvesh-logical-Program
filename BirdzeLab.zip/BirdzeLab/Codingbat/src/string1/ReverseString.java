package string1;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String string=sc.next();
		String reversedStr=" ";
		for(int i=string.length()-1;i>=0;i--) {
			reversedStr=reversedStr+string.charAt(i);
		}
		System.out.println("original string:"+string);
		System.out.println("-------------------------");
		System.out.println("Reversed string:"+reversedStr);
	}

}
