package string1;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
	int arr[]= {5,1,3,8,3,1,9,4,6,7};
	Arrays.sort(arr,4,8);
	String s=Arrays.toString(arr);
	System.out.println(s);
	
	}
}
