package String2;

import java.util.Arrays;

public class hrank {

	public static void main(String[] args) {
		
	int arr[]= {-1,1,2,3,-5};
	 {
	Arrays.sort(arr);
	System.out.println(Arrays.toString(arr));
	
	 }
	
	}
	
}