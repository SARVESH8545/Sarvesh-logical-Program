package String2;
// wap  program  to display first letter
import java.util.Scanner;

public class Str6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	System.out.println("User input string");
       String s=sc.next();
       char c=s.charAt(0);
      System.out.println(c);
       
		

	}

}
