package String2;

public class Count_Number_vowels {

	public static void main(String[] args) {
	String s="India is Great";
	s=s.replaceAll("[aeiouAEIOU]","");
	System.out.println(s);
	
	}

}
