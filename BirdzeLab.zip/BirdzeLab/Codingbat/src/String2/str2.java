package String2;

public class str2 {

	public static void main(String[] args) {
	String s="bananas";
	int n=s.indexOf('s');
	//int n=s.indexOf('a',2);
	//int n=s.lastIndexOf('a');
	//System.out.println(n);
//	boolean b=s.contains("ban");
//boolean b=s.contains("nab");
	System.out.println(n);

	
	
	}

}
