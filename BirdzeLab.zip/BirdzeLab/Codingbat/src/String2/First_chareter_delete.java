package String2;

public class First_chareter_delete {

	public static void main(String[] args) {
	String s="abcde";
	String t=s.substring(1);
	System.out.println(t);
	
	}

}
