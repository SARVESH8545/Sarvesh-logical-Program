package String2;

public class str3 {

	public static void main(String[] args) {
	String s="abcdefghij";
	//s=s.substring(5);//fghij
	s=s.substring(2,6);
	System.out.println(s);
	//String b="bananas";
	//b=b.replaceAll("a", "x");
	//b=b.replaceFirst("a","x");
	//b=b.replace("a", " ");
	//System.out.println(b);
	
	/*String sd="This is my  class room";
	sd=sd.replace(" ","");
	System.out.println(sd);*/
	}

}
