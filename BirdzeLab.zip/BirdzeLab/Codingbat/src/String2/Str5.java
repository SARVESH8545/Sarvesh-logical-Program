package String2;

import java.util.Arrays;

// sort with in range
public class Str5 {

	public static void main(String[] args) {
/*int arr[]= {5,1,3,8,3,1,9,4,6,7};
Arrays.sort(arr,4,8);
String s=Arrays.toString(arr);
Sy0stem.out.println(s);*/
		
		
		/*int a[]= {5,1,3,8,3,1,9,4,6,7};
		int b[]=Arrays.copyOfRange(a, 4,8);
		String s=Arrays.toString(b);
		System.out.println(s);*/
		
		// fill method
		/*int ar[]= {5,1,3,8,3,1,9,4,6,7};
		Arrays.fill(ar,4,8,-5);
		String s=Arrays.toString(ar);
		System.out.println(s);*/
		
		// Comparison of two Arrays
		int ar[]= {1,2,3,4};
		int br[]= {1,2,3,4};
		System.out.println(Arrays.equals(ar, br));
		
	}

}
