package String2;
// Wap to print a char to string of a new Line
public class Str8 {

	public static void main(String[] args) {
    String s="abcd";
    for(int i=0;i<s.length();i++) {
    	System.out.println(s.charAt(i));
    }

	}

}
