package String2;

public class str {

	public static void main(String[] args) {
	String s="abcd"	;
	s=s.toUpperCase();
	System.out.println(s);
	System.out.println("-----------------------");
	String str="HIJK";
	str=str.toLowerCase();
	System.out.println(str);
	System.out.println("=========================");
	String ss="bananas";
	int b=ss.length();
	System.out.println(b);
	System.out.println("------------------------------");

	
	}

}
