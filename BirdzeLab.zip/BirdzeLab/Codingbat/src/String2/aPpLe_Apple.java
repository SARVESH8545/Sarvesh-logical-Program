package String2;

public class aPpLe_Apple {

	public static void main(String[] args) {
		String s="aPple";
		String sh=s.substring(1);
		//System.out.println(sh);
		sh=sh.toLowerCase();
		String fh=""+s.charAt(0);
		fh=fh.toUpperCase();
		System.out.println(fh+sh);
		

	
		
	}

}
