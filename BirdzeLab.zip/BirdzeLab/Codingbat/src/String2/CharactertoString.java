package String2;

public class CharactertoString {

	public static void main(String[] args) {
    String s="bananas";
     char c='n';
     s=s.replace(""+c,"");
     System.out.println(s);

	}

}
