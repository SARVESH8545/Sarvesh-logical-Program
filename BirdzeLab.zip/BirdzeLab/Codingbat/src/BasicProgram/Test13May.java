package BasicProgram;

public class Test13May {

	public static void main(String[] args) {
		/*int a=5;
		int b=10;
		if (++a>0 && ++b>0) //6<0 && 11>0-->true
		{
			System.out.println("inside");
		}
      System.out.println(a);//6
      System.out.println(b);//11*/
		int a[]= {1,2,3,4,5};
		for (int i = 0;i<1; i++) {
			System.out.println(a[2]+" "+a[1]+" "+a[0]+" "+a[3]+" "+a[4]);
		}
	}

}
