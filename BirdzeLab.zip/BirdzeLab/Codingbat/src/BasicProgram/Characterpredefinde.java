package BasicProgram;

public class Characterpredefinde {

	public static void main(String[] args) {
		System.out.println("------Character to Integer------");
		System.out.println((int)'A');
		System.out.println((int)'a');
		System.out.println((int)'0');
		System.out.println((int)' ');
		System.out.println("-----------------------------------");
		System.out.println("------INteger to Character------");
		System.out.println((char)65);
		System.out.println((char)49);
		System.out.println((char)99);
		System.out.println("----------------------------------");
		System.out.println(((int)'A')+1);
		System.out.println("--------------------------------");
		System.out.println('A'+'A');
		System.out.println("--------------------------------");
		System.out.println((char)'A'+2);
		System.out.println("--------------------------------");
		System.out.println((char)('A'+2));
		
	}

}
