package BasicProgram;
// wap to check prime number
import java.math.BigInteger;

public class PrimeNumberNext1 {

	public static void main(String[] args) {
		BigInteger b=BigInteger.valueOf(11);
		System.out.println(b.isProbablePrime(2));
		
	}
}
