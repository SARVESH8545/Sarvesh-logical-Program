package BasicProgram;

public class Test {

	public static void main(String[] args) {
		int a=5;
	    // int b=a+ 0.5; // cannot convert from double to int
        double d=a+0.5;
           System.out.println(d);
	}

}
