package Javatpoint_String_program;

public class Testpractic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
