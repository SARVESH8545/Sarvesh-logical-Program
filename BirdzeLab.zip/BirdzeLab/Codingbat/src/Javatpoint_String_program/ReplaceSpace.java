package Javatpoint_String_program;

public class ReplaceSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String s="Once in a blue moon";
      s=s.replace(' ','-');
      System.out.println(s);
	}

}
