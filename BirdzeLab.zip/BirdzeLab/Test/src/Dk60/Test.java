package Dk60;

public class Test {

	public static void main(String[] args) {
		/* int i=5;
			i=i++;            //(a temporary variable will be created)
			i=i++;
			i=i++;
			i=i++;
			i=i++;
			i=i++;
			System.out.println(i); //5
			*/
		/*while(true)
		  {
		System.out.println("inside");
		  }
	     // System.out.println("inside");
*/
		
		/*int i=0;
		while(i<3)
		  {
		System.out.println("inside");
		  }
	//System.out.println("outside");
	 */
	/* int n=7;
		for (int i = 0; i <n; i++) {
			for (int j = 0; j <n; j++) {
				if(j>=n/2-i && j<=n-1-i && i<=n/2) {
				System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
		System.out.println();
			
		}*/
		
	/*/ prime Number	
		int n=17;
		int c=0;
		for (int i = 2; i <=n/2; i++) {
			if(n%i==0) {
					c++;
			break;
			}
		}
		if(c==0)
		{
			System.out.println("Prime Number");
		}
		else {
			System.out.println("Not a prime Number");
		}*/
		
		/*/ Lcm and Hcf
		int n=10,m=15,hcf=0;
		
		for(int i=1;i<=m;i++) { // i=1;i=2; i=3;i=5;i=10;
			if(n%i==0 && m%i==0) { //10%1==0 && 20%1==0->true true true
			hcf=i;	
			}
		}
		int product=m*n;
		int lcm=product/hcf;
		System.out.println(lcm);
	 
		
		System.out.println(Math.floor(-2.5));
		System.out.println(Math.log(100));
		System.out.println((int)' ');
		*/
		interface A{
			
		}
		
		

	}

}
