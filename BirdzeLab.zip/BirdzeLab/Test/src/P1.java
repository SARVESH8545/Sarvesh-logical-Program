import java.util.Arrays;

public class P1 {
//Write a Java program to sort a numeric array and a string array.
	public static void main(String[] args) {
		int ar1[]= {10,50,20,60,30,70,};
		String  ar2[]= {"java","python","php","c#","c++"};
        System.out.println("Original numeric array:"+Arrays.toString(ar1));
        Arrays.sort(ar1);
        System.out.println("sorted numeric array:"+Arrays.toString(ar1));
        System.out.println("-------------------------------------");
        System.out.println("Original string array:"+Arrays.toString(ar2));
        Arrays.sort(ar2);
        System.out.println("sorted string  array:"+Arrays.toString(ar2));
        
	}

}
