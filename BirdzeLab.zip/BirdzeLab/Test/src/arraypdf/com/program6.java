package arraypdf.com;

import java.util.Scanner;

public class program6 {

	public static void main(String[] args) {
		
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the size of array");
	int n=sc.nextInt();//3
	int m=sc.nextInt();//3
	// Declare a array
	int ar[][]=new int[n][m];
	System.out.println("Enter element into array");
	// Store the element into the array
	for (int i = 0; i < ar.length; i++) {
		
for (int j = 0; j < ar.length; j++) {
	ar[i][j]=sc.nextInt(); //10 10 10 20 20 20 30 30 30 
}
	}
	//Display the array element
	/*
	for (int i = 0; i < ar.length; i++) {
		for (int j = 0; j < ar.length; j++) {
			System.out.println(ar[i][j]+" "); //101010 202020 303030
			
		}
	}
	*/
	for (int  data[]: ar) {
		for (int Data: data) {
			System.out.println(Data);
			
		}
	}
	
	}

}
