package arraypdf.com;

import java.util.Scanner;

// wap a program to print difference b/w multiplication of even index and sum off odd index

public class Program18 {
//18)WAP to print difference between multiplication of even index and sum of odd index
	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the size of Array");
     int n=sc.nextInt();
     int ar[]=new int[n];
     System.out.println("Strore the array element in array:");
     for (int i = 0; i < ar.length; i++) {
		ar[i]=sc.nextInt();
		
	}
     int sum=0;
     for (int i = 0; i < ar.length; i=i+2) {
		sum=sum+ar[i];
	}
     System.out.println( "Sum"+sum);
     int mul=1;
     for (int i = 1; i < ar.length; i+=2) {
		mul=mul*ar[i];
		
	}
     System.out.println("MUl"+mul);
     System.out.println(mul-sum);

	}

}
