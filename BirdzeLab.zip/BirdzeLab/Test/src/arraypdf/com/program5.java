package arraypdf.com;

import java.util.Scanner;

//Character type Array
//05)Example-1(retrieve data for-each loop) 
public class program5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("size of array");
		int n=sc.nextInt();
		char ar[]=new char[n];
		System.out.println("Enter array element");
		for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.next().charAt(0);
			}
		System.out.println("print array element");
		for (char c : ar) {
		System.out.println(c);	
		}
	

	}

}
