package arraypdf.com;

import java.util.Scanner;
// WAP a program find the sum of array
public class program15 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// size of array
		System.out.println("Enter the size of array:");
		int n=sc.nextInt();
		int ar[]=new int[n]; 
		int sum=0;
		// store the element of array
		System.out.println("Enter the Array element:");
		for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.nextInt();
		}
		for (int i = 0; i < ar.length; i++) {
			
			// sum of array element
			sum=sum+ar[i];
		}
		System.out.println(sum);
		
	}

}
