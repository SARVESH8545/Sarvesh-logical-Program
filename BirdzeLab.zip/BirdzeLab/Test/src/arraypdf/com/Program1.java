package arraypdf.com;

import java.util.Scanner;

//01)Example-1(retrieve data for loop)
public class Program1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=sc.nextInt();
		int ar[]=new int[n];
		System.out.println("Enter the Array Element ");
		for (int i = 0; i < ar.length; i++) {
			 ar[i]=sc.nextInt();
			
		}
		// print the element of array
		for (int i = 0; i < ar.length; i++) {
			
			System.out.print(ar[i]);
		}
	

	}

}
