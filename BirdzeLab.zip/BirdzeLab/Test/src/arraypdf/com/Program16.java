package arraypdf.com;

import java.util.Scanner;
// WAP multilplication of even index
public class Program16 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n=sc.nextInt();
		int ar[]=new int[n];
		int mul=1;
		
		for (int i = 0; i < ar.length; i++) {
		ar[i]=sc.nextInt();
		}
		/*for(int i=1;i<n;i=i+2)*///for odd index
		for (int i = 0; i < ar.length; i=i+2) {
			mul=mul*ar[i];
		}
		System.out.println("Multiplaction of arrays element:"+mul);

	}

}
