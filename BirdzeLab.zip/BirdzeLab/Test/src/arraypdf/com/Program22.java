package arraypdf.com;

import java.util.Arrays;
import java.util.Scanner;

// WAP for magic Array
public class Program22 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size array:");
		int n=sc.nextInt();
		// Enter the size of array
		int ar[]=new int[n];
		//Enter element into the array
		System.out.println("Enter the array element:");
		for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.nextInt();
		}
		for (int i = 0; i < ar.length; i++) {
			
		
		System.out.print(ar[i]);
		}
		System.out.println();
		//copy the array  
		int sorted[]=ar.clone(); //10 40 20 30
       //sort the array
		Arrays.sort(sorted);  //10 20 30 40 
		//compare sorted and unsorted array
		for (int i = 0; i < sorted.length; i++) {
			
		
		System.out.print(sorted[i]);
		}
		System.out.println();
    int gd=0,bd=0;
    for (int i = 0; i < sorted.length; i++) {
	if(ar[i]==sorted[i]) {
		gd=gd+ar[i];
	   }
	 else {
		bd=bd+ar[i];
	 } 
   }
  System.out.println("gd:"+gd);
  System.out.println("bd:"+bd);
  System.out.println("gd-bd:"+(gd-bd));
	}

}
