package arraypdf.com;

import java.util.Scanner;

//String type array
// 03)Example-1(retrieve data for loop) 
public class program3 {

	public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter the size if array");
	 int n=sc.nextInt();
	 String ar[]=new String[n];
	 System.out.println("Enter the arraya element");
	 for (int i = 0; i < ar.length; i++) {
            ar[i]=sc.next();		
	}
	 /*/ print the array element
	 for (int i = 0; i < ar.length; i++) {
		System.out.println(ar[i]);
	}*/
	 
	 // print array element by for each loop
	 for (String data : ar) {
		 System.out.println(data);
		
	}

	}

}
