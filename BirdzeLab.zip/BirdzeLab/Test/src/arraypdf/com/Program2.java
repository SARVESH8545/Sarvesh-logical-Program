package arraypdf.com;

import java.util.Scanner;

//02)Example-2(retrieve data for-each loop) 
public class Program2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of array");
		int n=sc.nextInt(); //2
		int ar[]=new int[n];   // array size is fixed 2
		System.out.println("Enter the array element");
		for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.nextInt();   //10 20
		}
		// print the element from array
		for (int data : ar) 
		{
			System.out.println(data); //10 20
			
		}
		
		

	}

}
