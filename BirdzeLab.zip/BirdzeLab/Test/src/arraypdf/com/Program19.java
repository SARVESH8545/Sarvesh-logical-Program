package arraypdf.com;

import java.util.Arrays;
import java.util.Scanner;

public class Program19 {
//19)WAP to sort a array using won method concept 
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int ar[]=new int[n];
		for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.nextInt();
		}
		sortit(ar);
		for (int i = 0; i < ar.length; i++) {
			System.out.println(ar[i]);
		}
		
	}
	static void sortit(int br[]) {
		Arrays.sort(br);
		
	}

}
