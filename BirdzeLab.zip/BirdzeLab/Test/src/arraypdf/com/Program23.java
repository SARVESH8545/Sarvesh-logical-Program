package arraypdf.com;

import java.util.Arrays;
import java.util.Scanner;

//23)WAP to print accurance of element in given array
public class Program23 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of array");
         int n=sc.nextInt();
         int ar[]=new int[n];
         System.out.println("Enter element into the array");
         for (int i = 0; i < ar.length; i++) {
			ar[i]=sc.nextInt();
			}
        
         System.out.println();
         System.out.println("Sort the array element:");
         Arrays.sort(ar);
         
         String s=Arrays.toString(ar);
         s=s.replaceAll("[ ,]", "");
         s=s.replace("[","");
         s=s.replace("]", "");
        
         System.out.println(s);
         while(s.length()>0) 
         {
         char c=s.charAt(0);
       	 int occ=s.lastIndexOf(c)+1;	 
      	 System.out.println(c+"-- "+occ);
        	 s=s.replace(""+c,"");       	 
        	 
         }
        
         
	}

}
