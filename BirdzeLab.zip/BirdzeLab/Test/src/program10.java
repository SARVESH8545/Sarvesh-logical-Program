import java.util.Scanner;

public class program10 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the array Element");
	        int n=sc.nextInt();
	        int m=sc.nextInt();
	        int o=sc.nextInt();
	        // Declear a array
	        int ar[][][]=new int[n][m][o];
	        System.out.println("Enter element in to array");
	        //store  element into the array
	        for (int i = 0; i < ar.length; i++) {
				for (int j = 0; j < ar.length; j++) {
					for (int k = 0; k < ar.length; k++) {
						ar[i][j][k]=sc.nextInt();
					}
				}
			}
	        //Display the array element
	        for (int i = 0; i < ar.length; i++) {
				for (int j = 0; j < ar.length; j++) {
					for (int k = 0; k < ar.length; k++) {
						System.out.print( ar[i][j][k]+" ");
					}
					System.out.println();
				}
				System.out.println();
			}
	
	
	
	
	}

}
