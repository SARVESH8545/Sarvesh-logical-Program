//Write a Java program to calculate the average value of array elements

public class p3 {

	public static void main(String[] args) {
     int a[]= {10,20,30,40,};
     int tot=0;
     
     for (int i = 0; i < a.length; i++) {
		tot=tot+a[i];
	}
     int avg=tot/a.length;
     System.out.println(avg);

	}

}
