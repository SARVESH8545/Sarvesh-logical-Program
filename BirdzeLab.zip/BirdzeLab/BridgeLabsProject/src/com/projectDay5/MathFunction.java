package com.projectDay5;
import java.util.*;
public class MathFunction {

	private static final double cosine = 0;
	public static double harmonicNumber(int n)
		{
			double har=0.0;
			for(int i=1;i<=n;i++) {
				har+=1.0/i;
			}
			return har;
		}
	public static double sinofangle(double angle)
	{
		double radians=Math.toRadians(angle);
		double sin=Math.sin(radians);
		return sin;
	}
	public static double cosineofangle(double angle)
	{
		double radian=Math.toRadians(angle);
		double cosine=Math.cos(radian);
		return cosine;
	}
	public static int BinaryofNumber(int num)
	{
		String bin="";
		while(num>0) {
			bin=bin+(num%2);
			num=num/2;
		}
		String revbin="";
		for(int i=bin.length()-1;i>=0;i--) {
			revbin=revbin+bin.charAt(i);
		}
		int binary=Integer.parseInt(revbin);
		return binary;
	}
	public static double sqrt(double d) {
		double epsilon=1e-15;
		double t=d;
		while(Math.acos(t-d/t>epsilon*t)) {
			t=(d/t+t)/2.0;
		}
		return t;
	}

	public static boolean isPrime(int n) {
		int m=n/2;
		if(n==1||n==0)return false;
		else if(n==2)return true;
		else {
			for(int i=2;i<=m;i++) {
				if(n%i==0) {
					return false;
				}
			return true;
			}
		}
		return false;
		 
	}	
			
		
	private static int factorial(int n) {
   int fact=1;
   for(int i=1;i<=n;i++) {
   fact=fact*i;
   }
   return fact;
   }
	public static double compoundInterestFuturevalue(int c,double r,double t) {
	double futurevalue=c*Math.pow((1+r),t);
	return futurevalue;
	}
	public static double compoundInterestPresentvalue(int c,double r,double t) {
		double presentvalue=c*Math.pow((1+r),t);
		return presentvalue;
		}
	public static void maxandminInArray(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				int temp = 0;
				if(arr[j]>arr[j+1]) {
					arr[j+1]=temp;
				}
			}
		}
	System.out.println("max="+arr[arr.length-1]);
	System.out.println("min="+arr[0]);
	}
	public static boolean  checkCollinearUsingSlope (int x1,int y1,int x2,int y2,int x3,int y3) {
		double AB=(y2-y1)/(x2-x1);
		  double BC = (y3-y2)/(x3-x2) ;
		  double AC = (y3-y1)/(x3-x1) ;
		  if(AB==BC && BC==AC) {
			  return true;
			  }
		  return false;
	}
	public static boolean  checkCollinearUsingArea (int x1,int y1,int x2,int y2,int x3,int y3) {
		double a=x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2);
		  if(a==0) {
			  return true;
			  }
		  return false;
	}

public static boolean TriangleFormula(int x1,int y1,int x2,int y2,int x3,int y3) {
	double det=0.5*((y2-y3)*(x1-x2))-((y1-y2)*(x2-x3));
	double res=0.0;
	if( res==det) {
		return true;
	}
 return false; 
}
public static void main(String [] args) {
	
}
}


