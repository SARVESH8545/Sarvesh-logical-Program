package com.projectday1;

public class Error {

	public static void main(String[] args) 

	 {
	System.out.println("Error");
	}}


