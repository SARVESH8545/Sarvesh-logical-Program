import java.util.*;
class PrintThreeNames
{
	public static void main(String[] args) 
	{
		
System.out.println("hi");
for(int i=args.length-1;i>0;i--) {
	System.out.print(args[i]+",");
	
{	
System.out.print("and"+args[i]+".");
}
	}
	}
}
